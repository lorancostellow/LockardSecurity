<!-- Author: Lorna Costelloe-->
<!DOCTYPE html>
<?php
	//Start session
	session_start();	
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);
	unset($_SESSION['SESS_FIRST_NAME']);
	unset($_SESSION['SESS_LAST_NAME']);
?>
<html>
	<head> 
		<meta charset="UTF-8" />
	   <link rel="stylesheet" type="text/css" media="all" href="/css/style.css" />
	    <title>Lockard Security</title>
	</head>
	<body>  
		<header>
		<div class ="logo">
			<img src ="/lockard_logo.png" width="500" height="300 alt="Lockard Security Logo">
		</div>
	    <div class="nav">
	      <ul>
	        <li class="home"><a class="active" href="/hello.php">Home</a></li>
	        <li class="signin"><a href="/settings.php">Settings</a></li>
	      </ul>
	    </div>
	  </header>

	<div class ="images">
		<img src="https://placeholdit.imgix.net/~text?txtsize=33&txt=500%C3%97300&w=500&h=300">
	</div>

	<div class="account">
		<div class="login">
     	 	<h1>Login to Lockard Security</h1>
      		<form method="post" action="settings.php">
      		<!--the code bellow is used to display the message of the input validation-->
		 	<?php
			if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR'])>0 ) {
			echo '<ul class="err">';
			foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				echo '<li>',$msg,'</li>'; 
				}
			echo '</ul>';
			unset($_SESSION['ERRMSG_ARR']);
			}?>
      		<br><br>
        	<p><input type="text" name="login" value="" placeholder="Username"></p>
      		<br><br>
        	<p><input type="text" name="password" value="" placeholder="Password"></p>
      		<br><br>
        	<p class="submit"><input type="submit" name="commit" value="Login"></p>
    	  </form>
		<p class="remember_me">
          	<label>
			<br>
			Remember me on this computer
            <input type="checkbox" name="remember_me" id="remember_me">
          	</label>
        	</p>
        	<br><br><br><br>
    	</div>
	</div>
  </body>
	<footer></footer>
</html>