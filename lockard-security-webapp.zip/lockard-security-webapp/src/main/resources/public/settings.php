<!-- Author: Lorna Costelloe-->
<?php
	require_once('auth.php');
?>
<!DOCTYPE html>
<html>
	<head> 
		<meta charset="UTF-8" />
	   <link rel="stylesheet" type="text/css" media="all" href="/css/style.css" />
	   <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	    <title>Lockard Security</title>
	    <script type="text/javascript">
		
		/***********************************************
		* Drop Down Date select script- by JavaScriptKit.com
		* This notice MUST stay intact for use
		* Visit JavaScript Kit at http://www.javascriptkit.com/ for this script and more
		***********************************************/
		
			var monthtext=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sept','Oct','Nov','Dec'];
			
			function populatedropdown(dayfield, monthfield, yearfield){
			var today=new Date()
			var dayfield=document.getElementById(dayfield)
			var monthfield=document.getElementById(monthfield)
			var yearfield=document.getElementById(yearfield)
			for (var i=0; i<31; i++)
			dayfield.options[i]=new Option(i, i+1)
			dayfield.options[today.getDate()]=new Option(today.getDate(), today.getDate(), true, true) //select today's day
			for (var m=0; m<12; m++)
			monthfield.options[m]=new Option(monthtext[m], monthtext[m])
			monthfield.options[today.getMonth()]=new Option(monthtext[today.getMonth()], monthtext[today.getMonth()], true, true) //select today's month
			var thisyear=today.getFullYear()
			for (var y=0; y<20; y++){
			yearfield.options[y]=new Option(thisyear, thisyear)
			thisyear+=1
			}
			yearfield.options[0]=new Option(today.getFullYear(), today.getFullYear(), true, true) //select today's year
			}
		
		</script>
		
		<script>
			$(function () {
		    $("#checkAll").click(function () {
		        if ($("#checkAll").is(':checked')) {
		            $(".heating").prop("checked", true);
		        } else {
		            $(".heating").prop("checked", false);
		        }
		    });
			});
		</script>
	</head>
	<body>  
		<header>
		<div class ="logo">
			<img src ="/LOGO_PLACEHOLDER.PNG" alt="Lockard Security Logo">
		</div>
	    <div class="nav">
	      <ul>
	        <li class="home"><a href="/hello.php">Home</a></li>
	        <li class="signin"><a class="active" href="/settings.php">Settings</a></li>
	      </ul>
	    </div>
	  </header>
	  <br><br><br><br>
	<div class="tabs">
	   <ul>
	    <li class="current"><a href="#HEATING">Heating</a></li>
	    <li><a href="#H_ALARM">House Alarm</a></li>
	    <li><a href="#F_ALARM">Fire Alarm</a></li>
	    <li><a href="#C_ALARM">Carbon Monoxide Alarm</a></li>
	    <li><a href="#LIGHTING">Lighting</a></li>
	   </ul>
	  <div>
	   <div id="HEATING" class="tab-content">
	   		<form action="" method="post">
			  <input type="checkbox" name="checkAll" id="checkAll" /> Turn my heating on
			  <br>
			  <input type="checkbox" name="heating" value="updateYes" /> I want updates on this every 
			  <select name="Select Value">
 				  <option value="4">4</option>
 				  <option value="8">8</option>
				  <option value="12">12</option>
				  <option value="24">24</option>
				  </select>
				  hours.
			 <br><br>
			 <p>Please check on the hours you would like your heating on.  </p>
			<br>
				<div id="AM">
					<?php
						$sql = "SELECT status FROM Events WHERE name = "12am"";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="hour" class="heating" value="12" <?php echo $checked;?> 12AM - 1AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "1am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
		   			<p>   </p><input type="checkbox" name="hour" class="heating" value="1" <?php echo $checked;?> 1AM - 2AM<br>
		   			
		   			<?php
						$sql = "SELECT status FROM Events WHERE name = "2am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="hour" class="heating" value="2" <?php echo $checked;?> 2AM - 3AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "3am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="hour" class="heating" value="3" <?php echo $checked;?> 3AM - 4AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "4am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="4am" class="heating"  value="4" <?php echo $checked;?> 4AM - 5AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "5am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="5am" class="heating"  value="5" <?php echo $checked;?> 5AM - 6AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "6am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="6am" class="heating" value="6" <?php echo $checked;?> 6AM - 7AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "7am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="7am" class="heating"  value="7" <?php echo $checked;?> 7AM - 8AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "8am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="8am" class="heating" value="8" <?php echo $checked;?> 8AM - 9AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "9am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="option9" class="heating"  value="9" <?php echo $checked;?> 9AM - 10AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "10am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="10am" class="heating" value="10" <?php echo $checked;?> 10AM - 11AM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "11am";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="11am" class="heating" value="11" <?php echo $checked;?> 11AM - 12PM<br>
				</div>
				<div id="PM">
				<?php
						$sql = "SELECT status FROM Events WHERE name = "12pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="12pm" class="heating" value="12" <?php echo $checked;?> 12PM - 1PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "1pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
		   			<p>   </p><input type="checkbox" name="1pm" class="heating" value="1" <?php echo $checked;?> 1PM - 2PM<br>
		   			
		   			<?php
						$sql = "SELECT status FROM Events WHERE name = "2pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="2pm" class="heating" value="2" <?php echo $checked;?> 2PM - 3PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "3pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="3pm" class="heating" value="3" <?php echo $checked;?> 3PM - 4PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "4pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="4pm" class="heating" value="4" <?php echo $checked;?> 4PM - 5PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "5pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="5pm" class="heating" value="5" <?php echo $checked;?> 5PM - 6PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "6pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="6pm" class="heating" value="6" <?php echo $checked;?> 6PM - 7PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "7pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="7pm" class="heating" value="7" <?php echo $checked;?> 7PM - 8PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "8pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="8pm" class="heating" value="8" <?php echo $checked;?> 8PM - 9PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = 9pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="9pm" class="heating" value="9" <?php echo $checked;?> 9PM - 10PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "10pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="10pm" class="heating" value="10" <?php echo $checked;?> 10PM - 11PM<br>
					
					<?php
						$sql = "SELECT status FROM Events WHERE name = "11pm";
						$result = $conn-&gt;query($sql);
						$checked = ($status)?'checked="checked"':'';
					?>
					<p>   </p><input type="checkbox" name="11pm" class="heating" value="11" <?php echo $checked;?> 11PM - 12AM<br>
					
				</div>
				
			 <br><br>
			 <form action="demo_form.asp">
  				Keep house at <input type="number" name="temperature"> &deg; C at all times.<br>
  				Repeat these settings daily until 
  				<form action="" name="someform">
				<select id="daydropdown">
				</select> 
				<select id="monthdropdown">
				</select> 
				<select id="yeardropdown">
				</select> 
				</form>
				
				<script type="text/javascript">
				
				//populatedropdown(id_of_day_select, id_of_month_select, id_of_year_select)
				window.onload=function(){
				populatedropdown("daydropdown", "monthdropdown", "yeardropdown")
				}
</script>
  			</form>
  			<br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
			</form>
	   </div>
	   
	   <div id="H_ALARM" class="tab-content">
	  		 <form action="" method="post">
			  <input type="checkbox" name="H_ALARM" value="Halert" /> Alert me if my house alarm turns on
			  <br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
			</form>
	    </div>
	    
	   <div id="F_ALARM" class="tab-content">
	   		<form>
	  		 <input type="checkbox" name="F_ALARM" value="Falert" /> Alert me if my fire alarm turns on
	  		 <br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
	  		</form>
	   </div>
	   
	   <div id="C_ALARM" class="tab-content">
	   	  <form>
	   		<input type="checkbox" name="C_ALARM" value="Calert" /> Alert me if my Carbon Monoxide alarm turns on
	   	    <br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
	   	  </form>
	   	</div>
	   	
	   	<div id="LIGHTING" class="tab-content">
	   		<input type="checkbox" name="lighting" value="Lighting" /> Turn off all my lights please.
	   		<br><br>
	   		<input type="checkbox" name="light" value="updatesYes" /> I want updates on this every 
			  <select name="Select Value">
 				  <option value="4">4</option>
 				  <option value="8">8</option>
				  <option value="12">12</option>
				  <option value="24">24</option>
				  </select>
				  hours.
			 <br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
	   	</div>
	  </div>
	 </div>
	 
		 <script type="text/javascript">
	
			$(document).ready(function(){
			 $(".tabs li").click(function() {
			  $(this).parent().parent().find(".tab-content").hide();
			  var selected_tab = $(this).find("a").attr("href");
			  $(selected_tab).fadeIn();
			  $(this).parent().find("li").removeClass('current');
			  $(this).addClass("current");
			   return false;
			    });
			});
		  </script>
  </body>
	<footer></footer>
</html>