<!-- Author: Lorna Costelloe-->
<!DOCTYPE html>
<html>
	<head> 
		<meta charset="UTF-8" />
	   <link rel="stylesheet" type="text/css" media="all" href="/css/style.css" />
	   <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	    <title>Lockard Security</title>
	    <script type="text/javascript">
		
		/***********************************************
		* Drop Down Date select script- by JavaScriptKit.com
		* This notice MUST stay intact for use
		* Visit JavaScript Kit at http://www.javascriptkit.com/ for this script and more
		***********************************************/
		
			var monthtext=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sept','Oct','Nov','Dec'];
			
			function populatedropdown(dayfield, monthfield, yearfield){
			var today=new Date()
			var dayfield=document.getElementById(dayfield)
			var monthfield=document.getElementById(monthfield)
			var yearfield=document.getElementById(yearfield)
			for (var i=0; i<31; i++)
			dayfield.options[i]=new Option(i, i+1)
			dayfield.options[today.getDate()]=new Option(today.getDate(), today.getDate(), true, true) //select today's day
			for (var m=0; m<12; m++)
			monthfield.options[m]=new Option(monthtext[m], monthtext[m])
			monthfield.options[today.getMonth()]=new Option(monthtext[today.getMonth()], monthtext[today.getMonth()], true, true) //select today's month
			var thisyear=today.getFullYear()
			for (var y=0; y<20; y++){
			yearfield.options[y]=new Option(thisyear, thisyear)
			thisyear+=1
			}
			yearfield.options[0]=new Option(today.getFullYear(), today.getFullYear(), true, true) //select today's year
			}
		
		</script>
	</head>
	<body>  
		<header>
		<div class ="logo">
			<img src ="/LOGO_PLACEHOLDER.PNG" alt="Lockard Security Logo">
		</div>
	    <div class="nav">
	      <ul>
	        <li class="home"><a href="/hello.php">Home</a></li>
	        <li class="products"><a href="/products.php">Products</a></li>
	        <li class="about"><a href="/about.php">About Us</a></li>
	        <li class="contact"><a href="/contact.php">Contact Us</a></li>
	        <li class="signin"><a class="active" href="/login.php">Log In</a></li>
	      </ul>
	    </div>
	  </header>
	  <br><br><br><br>
	<div class="tabs">
	   <ul>
	    <li class="current"><a href="#HEATING">Heating</a></li>
	    <li><a href="#H_ALARM">House Alarm</a></li>
	    <li><a href="#F_ALARM">Fire Alarm</a></li>
	    <li><a href="#C_ALARM">Carbon Monoxide Alarm</a></li>
	   </ul>
	  <div>
	   <div id="HEATING" class="tab-content">
	   		<form action="" method="post">
			  <input type="checkbox" name="heating" value="On" /> Turn my heating on
			  <br>
			  <input type="checkbox" name="heating" value="updateYes" /> I want updates on this every 
			  <select name="Select Value">
 				  <option value="4">4</option>
 				  <option value="8">8</option>
				  <option value="12">12</option>
				  <option value="24">24</option>
				  </select>
				  hours.
			 <br><br>
			 <p>Please check on the hours you would like your heating on.  </p>
			<br>
				<div id="AM">
		   			<p>   </p><input type="checkbox" name="option1" value="1"> 1AM - 2AM<br>
					<p>   </p><input type="checkbox" name="option2" value="2"> 2AM - 3AM<br>
					<p>   </p><input type="checkbox" name="option3" value="3"> 3AM - 4AM<br>
					<p>   </p><input type="checkbox" name="option4" value="4"> 4AM - 5AM<br>
					<p>   </p><input type="checkbox" name="option5" value="5"> 5AM - 6AM<br>
					<p>   </p><input type="checkbox" name="option6" value="6"> 6AM - 7AM<br>
					<p>   </p><input type="checkbox" name="option7" value="7"> 7AM - 8AM<br>
					<p>   </p><input type="checkbox" name="option8" value="8"> 8AM - 9AM<br>
					<p>   </p><input type="checkbox" name="option9" value="9"> 9AM - 10AM<br>
					<p>   </p><input type="checkbox" name="option10" value="10"> 10AM - 11AM<br>
					<p>   </p><input type="checkbox" name="option11" value="11"> 11AM - 12PM<br>
				</div>
				<div id="PM">
		   			<p>   </p><input type="checkbox" name="option1" value="1"> 1PM - 2PM<br>
					<p>   </p><input type="checkbox" name="option2" value="2"> 2PM - 3PM<br>
					<p>   </p><input type="checkbox" name="option3" value="3"> 3PM - 4PM<br>
					<p>   </p><input type="checkbox" name="option4" value="4"> 4PM - 5PM<br>
					<p>   </p><input type="checkbox" name="option5" value="5"> 5PM - 6PM<br>
					<p>   </p><input type="checkbox" name="option6" value="6"> 6PM - 7PM<br>
					<p>   </p><input type="checkbox" name="option7" value="7"> 7PM - 8PM<br>
					<p>   </p><input type="checkbox" name="option8" value="8"> 8PM - 9PM<br>
					<p>   </p><input type="checkbox" name="option9" value="9"> 9PM - 10PM<br>
					<p>   </p><input type="checkbox" name="option10" value="10"> 10PM - 11PM<br>
					<p>   </p><input type="checkbox" name="option11" value="11"> 11PM - 12AM<br>
				</div>
				
			 <br><br>
			 <form action="demo_form.asp">
  				Keep house at <input type="number" name="temperature"> &deg; C at all times.<br>
  				Repeat these settings daily until 
  				<form action="" name="someform">
				<select id="daydropdown">
				</select> 
				<select id="monthdropdown">
				</select> 
				<select id="yeardropdown">
				</select> 
				</form>
				
				<script type="text/javascript">
				
				//populatedropdown(id_of_day_select, id_of_month_select, id_of_year_select)
				window.onload=function(){
				populatedropdown("daydropdown", "monthdropdown", "yeardropdown")
				}
</script>
  			</form>
  			<br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
			</form>
	   </div>
	   
	   <div id="H_ALARM" class="tab-content">
	  		 <form action="" method="post">
			  <input type="checkbox" name="H_ALARM" value="Halert" /> Alert me if my house alarm turns on
			  <br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
			</form>
	    </div>
	    
	   <div id="F_ALARM" class="tab-content">
	   		<form>
	  		 <input type="checkbox" name="F_ALARM" value="Falert" /> Alert me if my fire alarm turns on
	  		 <br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
	  		</form>
	   </div>
	   
	   <div id="C_ALARM" class="tab-content">
	   	  <form>
	   		<input type="checkbox" name="C_ALARM" value="Calert" /> Alert me if my Carbon Monoxide alarm turns on
	   	    <br><br>
	   	    <a href="#" class="submit">Apply Changes</a>
	   	  </form>
	   	</div>
	  </div>
	 </div>
	 
		 <script type="text/javascript">
	
			$(document).ready(function(){
			 $(".tabs li").click(function() {
			  $(this).parent().parent().find(".tab-content").hide();
			  var selected_tab = $(this).find("a").attr("href");
			  $(selected_tab).fadeIn();
			  $(this).parent().find("li").removeClass('current');
			  $(this).addClass("current");
			   return false;
			    });
			});
		  </script>
  </body>
	<footer></footer>
</html>