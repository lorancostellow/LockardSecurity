package com.lockard.lockardsecurity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.lockard.lockardsecurity.PiCom.Core.ComUtils;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PayloadEvent;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PayloadObject;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PayloadType;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PiDataObject;

/**
 * Created by monika on 16/04/16.
 * Source belongs to Lockard_Android_Application
 */
public class Home extends AppCompatActivity {

    TextView lightStat, alarmStat;
    String panic;
    Switch switchC, switchL;
    Button button;
    Boolean panicActivated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        lightStat = (TextView) findViewById(R.id.light_stat_text_view);
        alarmStat = (TextView) findViewById(R.id.house_stat_text_view);
        switchC = (Switch) findViewById(R.id.house_alarm_switch);
        switchL = (Switch) findViewById(R.id.light_switch);
        button = (Button) findViewById(R.id.panic_btn);
        panic = "Panic Button Activated";
        panicActivated = false;
    }

    public void panic(View view) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!panicActivated){
                    panicActivated = true;
                    panic = "Panic Button Activated";
                }else{
                    panicActivated = false;
                    panic = "Panic Button Deactivated";
                }
            }
        });
        Toast toast = Toast.makeText(getApplicationContext(), panic, Toast.LENGTH_SHORT);
        toast.show();
    }

    public void alarmSetting(View view) {
        if (switchC != null) {
            switchC.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        alarmStat.setTextColor(Color.parseColor("#00D213"));
                        alarmStat.setText("");
                        alarmStat.setText(R.string.alarm_stat_ON_text_view);
                        //token "blahh" user logs in with a token
                        PayloadObject payloadObj = new PayloadObject("BLAAH",
                                new PiDataObject("1", true), //id of sensor, value
                                "<BLANK>", //role
                                PayloadEvent.H_ALARM,
                                PayloadType.REQ);

                        ComUtils.setSerializedObject(payloadObj);


                    } else {
                        alarmStat.setTextColor(Color.parseColor("#FF0505"));
                        alarmStat.setText("");
                        alarmStat.setText(R.string.alarm_stat_text_view);
                    }
                }
            });
        }
    }

    public void lightSetting(View view) {
        if (switchL != null) {
            switchL.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        lightStat.setTextColor(Color.parseColor("#00D213"));
                        lightStat.setText("");
                        lightStat.setText(R.string.light_stat_ON_text_view);
                    } else {
                        lightStat.setTextColor(Color.parseColor("#FF0505"));
                        lightStat.setText("");
                        lightStat.setText(R.string.light_stat_text_view);
                    }
                }
            });
        }
    }
}
