package com.lockard.lockardsecurity.PiCom.PayloadModel;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * Created by dylan on 24/04/16.
 * Source belongs to Lockard
 */
public class PiDataObject implements PiData {
    private String sensorID;
    private Object data;

    public PiDataObject(String sensorID, Object data) {
        this.sensorID = sensorID;
        this.data = data;
    }

    public PiDataObject(String json) {
        JSONObject object = null;
        try {
            object = new JSONObject(json);
            sensorID = object.getString(PAYLOAD_SENSOR_ID);
            data = object.get(PAYLOAD_DATA_FIELD);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getSensorID() {
        return sensorID;
    }

    @Override
    public Object getData() {
        return data;
    }

    @Override
    public String getSerial() {
        JSONObject objectMap = new JSONObject();
        try {
            objectMap.put(PAYLOAD_SENSOR_ID, sensorID);
            objectMap.put(PAYLOAD_DATA_FIELD, data);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return objectMap.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PiDataObject that = (PiDataObject) o;

        if (sensorID != null ? !sensorID.equals(that.sensorID) : that.sensorID != null) return false;
        return data != null ? data.equals(that.data) : that.data == null;

    }

    @Override
    public int hashCode() {
        int result = sensorID != null ? sensorID.hashCode() : 0;
        result = 31 * result + (data != null ? data.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "PiData{" +
                "sensorID='" + sensorID + '\'' +
                ", data=" + data +
                '}';
    }
}
