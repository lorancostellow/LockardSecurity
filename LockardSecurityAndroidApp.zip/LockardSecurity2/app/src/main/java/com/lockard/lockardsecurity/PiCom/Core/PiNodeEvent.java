package com.lockard.lockardsecurity.PiCom.Core;

import com.lockard.lockardsecurity.PiCom.PayloadModel.Payload;

/**
 * Created by dylan on 20/04/16.
 * Source belongs to Lockard_PiComAPI
 */
public interface PiNodeEvent {
    Payload invoked(Payload received);
}
