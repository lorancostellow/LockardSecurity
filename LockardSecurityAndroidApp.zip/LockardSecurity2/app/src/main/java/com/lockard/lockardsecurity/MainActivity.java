package com.lockard.lockardsecurity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.lockard.lockardsecurity.PiCom.PayloadModel.MalformedPayloadException;
import com.lockard.lockardsecurity.PiCom.PayloadModel.Payload;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PayloadEvent;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PayloadObject;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PayloadType;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PiDataObject;

import org.json.JSONException;

/**
 * Created by monika on 16/04/16.
 * Source belongs to Lockard_Android_Application
 */

public class MainActivity extends AppCompatActivity {
    Button login;
    EditText token;
    AlertDialog.Builder builder;
    ImageView img;
    Client client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = (Button) findViewById(R.id.button);
        builder = new AlertDialog.Builder(this);
        img = (ImageView) findViewById(R.id.imageView2);
        client = new Client("192.168.2.5", 8000);
    }

    public void infoBox(View view) {
        assert img != null;
        img.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                builder.setMessage("Lockard is a home security management system. It lets you manage your lights, heating," +
                        "house alarm and much more. \n\n" +
                        "Don't have a token and would like to sign up? Please visit our website.")
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) { }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }

    public void login(View view) throws MalformedPayloadException, JSONException {
        client.send(new PayloadObject("<BLANK>", new PiDataObject("tlk", "token YOLO"), PayloadEvent.AUTH, PayloadType.REQ));
        Payload received = client.rcev();
        if(received.getData().getData().equals(true)){
            //log user in
        }else{
            //you a spa and don't have the right token.. ya twat
        }

        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }


}
