package com.lockard.lockardsecurity;

import com.lockard.lockardsecurity.PiCom.PayloadModel.Payload;

/**
 * Created by monika on 29/04/16.
 */
public class DataUtils {
    public static Payload send(Payload payload){

        return null;
    }

}
