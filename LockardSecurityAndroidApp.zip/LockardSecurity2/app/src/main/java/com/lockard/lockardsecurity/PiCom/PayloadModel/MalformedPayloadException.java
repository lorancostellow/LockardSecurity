package com.lockard.lockardsecurity.PiCom.PayloadModel;

public class MalformedPayloadException extends Throwable {
    public MalformedPayloadException(String message) {
        super(message);
    }
}
