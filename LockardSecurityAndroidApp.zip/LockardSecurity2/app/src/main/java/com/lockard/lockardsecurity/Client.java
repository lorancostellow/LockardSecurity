package com.lockard.lockardsecurity;

/**
 * Created by monika on 16/04/16.
 * Source belongs to Lockard_Android_Application
 */

import com.lockard.lockardsecurity.PiCom.Core.ComUtils;
import com.lockard.lockardsecurity.PiCom.PayloadModel.MalformedPayloadException;
import com.lockard.lockardsecurity.PiCom.PayloadModel.Payload;
import com.lockard.lockardsecurity.PiCom.PayloadModel.PayloadObject;

import org.json.JSONException;
import org.zeromq.ZMQ;

public class Client {
    private ZMQ.Context context;
    private ZMQ.Socket socket;

    public Client(String address, int port) {
        context = ZMQ.context(1);
        socket = context.socket(ZMQ.PAIR);
        socket.connect("tcp://" + address + ":" + port);
    }

    public void send(Payload payload){
        socket.send(ComUtils.setSerializedObject(payload));
    }

    public Payload rcev() throws MalformedPayloadException, JSONException {
        return new PayloadObject(new String(socket.recv()));
    }

    public void close(){
        socket.close();
        context.term();
    }
}