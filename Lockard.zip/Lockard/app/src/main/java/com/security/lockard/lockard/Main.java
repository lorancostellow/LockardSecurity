package com.security.lockard.lockard;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Main extends Activity {

    private static WebView lockardSecWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lockardSecWeb = (WebView)findViewById(R.id.webView);
        //this is where the url will go fr the website
        //the app is then done
        String url = "http://www.google.com";
        lockardSecWeb.getSettings().getJavaScriptEnabled();
        lockardSecWeb.loadUrl(url);

    }


}
